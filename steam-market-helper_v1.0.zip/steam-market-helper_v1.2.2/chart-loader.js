// chart-loader.js
window.chartJsPromise = Promise.resolve();
console.log("Chart.js loader initialized");